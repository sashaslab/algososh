import React from "react";
import { SolutionLayout } from "../ui/solution-layout/solution-layout";
import { Input } from "../ui/input/input";
import { Button } from "../ui/button/button";
import styles from './queue.module.css'
import { Queue } from "./queue";
import { Circle } from "../ui/circle/circle";
import { ElementStates } from "../../types/element-states";

export const QueuePage: React.FC = () => {
  const [value, setValue] = React.useState('');
  const array = React.useRef(new Queue<number>(7))
  const [queue, setQueue] = React.useState<(number | null | string)[]>(Array(7).fill(''));
  const [colorHead, setColorHead] = React.useState(false)
  const [colorTail, setColorTail] = React.useState(false)
  const [buttonDisabled, setButtonDisabled] = React.useState({
    delete: true,
    clear: true
  })

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    array.current.enqueue(Number(value))
    setButtonDisabled({...buttonDisabled, delete: false, clear: false})
    setQueue([...array.current.elements])
    setValue('')
    setColorHead(true)
    setTimeout(() => {
      setColorHead(false)
    }, 500)
  }


  return (
    <SolutionLayout title="Очередь">
      <form className={styles.form} onSubmit={(e) => {onSubmit(e)}}>
        <div className={styles.content}>
        <Input extraClass={styles.input} maxLength={4} isLimitText value={value} onChange={(e) => {
          e.preventDefault();
          setValue(e.currentTarget.value)
        }}/>
        <Button type="submit" text="Добавить" disabled={value === '' ? true : false} />
        <Button text="Удалить" disabled={array.current.peak() === null ? true : false } onClick={() => {
          setColorTail(true);
          setTimeout(() => {
            array.current.dequeue()
            setQueue([...array.current.elements])
            setColorTail(false)
          }, 500)
        }}/>
        </div>
        <Button text="Очистить" disabled={array.current.peak() === null ? true : false} onClick={() => {
          array.current.clear()
          setQueue(Array(7).fill(''))
        }}/>
      </form>

      <div className={styles.bubble}>
        {queue.map((item, index) => {
          return <Circle key={index} letter={item?.toString()} index={index} head={item !== '' && index === array.current.headIndex ? 'head' : ''} tail={item !== '' && index === array.current.tailIndex ? 'tail' : ''} state={(colorHead && index === array.current.tailIndex) || (colorTail && index === array.current.headIndex) ? ElementStates.Changing : ElementStates.Default}/>
        })}
      </div>
    </SolutionLayout>
  );
};
