import React from "react";
import { SolutionLayout } from "../ui/solution-layout/solution-layout";
import { Input } from "../ui/input/input";
import { Button } from "../ui/button/button";
import styles  from './stack.module.css';
import { Circle } from "../ui/circle/circle";
import {Stack} from "./stack";
import { ElementStates } from "../../types/element-states";

export const StackPage: React.FC = () => {

  const [value, setValue] = React.useState<string>('')
  const array = React.useRef(new Stack<number>())
  const [stack, setStack] = React.useState<number[]>([])
  const [color, setColor] = React.useState<boolean>(false);

  // if(value === '') {
  //   setButtonDisabled({...buttonDisabled, add: true})
  // }

  const onClick = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setColor(true)
    array.current.push(Number(value))
    setStack([...array.current.elements])
    setValue('')
    setTimeout(() => {
      setColor(false)
    }, 500)
  }

  return (
    <SolutionLayout title="Стек">
      <form className={styles.content} onSubmit={e => {
        if(value !== '') {
          onClick(e)
        } else {
          e.preventDefault()
        }
      }
        }>
        <div className={styles.container}>
        <Input placeholder="Введите число" isLimitText type="text" maxLength={4}  value={value} extraClass={styles.input} onChange={(e) => {
            setValue(e.currentTarget.value)
        }}/>

        <Button type="submit" text="Добавить"  disabled={value === '' ? true : false} />
      <Button text="Удалить" disabled={stack.length === 0 ? true : false}  onClick={() => {
        array.current.pop()
        setStack([...array.current.elements]);
        setColor(true);
        setTimeout(() => {
          setColor(false);
        }, 500)
      }}/>
        </div>
      <Button text="Очистить" disabled={stack.length === 0 ? true : false} onClick={() => {
        array.current.clear()
        setStack([...array.current.elements])
      }}/>
      </form>

      <div className={styles.bubble}>
       {stack.map((item, index) => {
        return <Circle key={index} letter={item.toString()} head={index === array.current.size - 1 ?  'top' : null} tail={`${index}`} state={color && index === array.current.size - 1 ? ElementStates.Changing : ElementStates.Default}/>
       })}
      </div>
    </SolutionLayout>
  );
};
